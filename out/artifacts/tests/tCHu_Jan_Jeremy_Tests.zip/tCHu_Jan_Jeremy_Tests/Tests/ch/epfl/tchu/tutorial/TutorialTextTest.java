package ch.epfl.tchu.tutorial;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TutorialTextTest {

    @Test
    void works() {
        TutorialText text = new TutorialText();
        text.readText();

    }

}