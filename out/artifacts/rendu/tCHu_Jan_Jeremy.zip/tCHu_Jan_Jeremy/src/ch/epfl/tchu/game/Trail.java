package ch.epfl.tchu.game;

import java.util.ArrayList;
import java.util.List;
/**
 * A Trail composed by one or more routes
 *
 * @author Yann Ennassih (329978)
 * @author Jérémy Barghorn (328403)
 */
public final class  Trail {
    private final int length;
    private final Station station1;
    private final Station station2;
    private final List<Route> routesOfTrail;

    /**
     * Private constructor of the class
     * @param station1 first station of the trail
     * @param station2 last station of the trail
     * @param routesOfTrail that compose the trail
     * @param length of the trail
     */
    private Trail(Station station1, Station station2, List<Route> routesOfTrail, int length) {
        this.station1 = station1;
        this.station2 = station2;
        this.routesOfTrail = routesOfTrail;
        this.length = length;
    }

    /**
     * Creates the longest trail with a given list of routes
     * @param routes list of routes
     * @return the longest trail constructed by the given routes
     * If routes is empty, returns a 0-long trail, with station 1 and station2 null
     * If they are multiple longest trails, returns an arbitrary one
     */
    public static Trail longest(List<Route> routes){
        List<Trail> listOfTrailsToExtend = new ArrayList<>();
        for(Route route : routes){
            listOfTrailsToExtend.add(new Trail(route.station1(), route.station2(), List.of(route), route.length()));
            listOfTrailsToExtend.add(new Trail(route.station2(), route.station1(), List.of(route), route.length()));
        }
        Trail longestTrail = listOfTrailsToExtend.get(0);
        while(!listOfTrailsToExtend.isEmpty()){
            longestTrail = listOfTrailsToExtend.get(0);
            List<Trail> newListOfTrailsToExtend = new ArrayList<>();
            for (Trail trailToExtend : listOfTrailsToExtend) {
                List<Route> prolongations = new ArrayList<>();
                for(Route possibleProlongation : routes) {
                    if(possibleProlongation.stations().contains(trailToExtend.station2)
                            && !trailToExtend.routesOfTrail.contains(possibleProlongation)){

                        prolongations.add(possibleProlongation);
                    }
                }
                for(Route prolongation : prolongations){
                    List<Route> listOfRoutesInTheTrail = trailToExtend.routesOfTrail;
                    listOfRoutesInTheTrail.add(prolongation);
                    assert trailToExtend.station2() != null;
                    newListOfTrailsToExtend.add(new Trail(trailToExtend.station1(),
                                                prolongation.stationOpposite(trailToExtend.station2()),
                                                listOfRoutesInTheTrail,
                                                trailToExtend.length()+prolongation.length()));
                }
            }
            listOfTrailsToExtend = newListOfTrailsToExtend;
        }
        return longestTrail;
    }

    /**
     * Getter for the attribute length
     * @return the attribute length
     */
    public int length(){
        return length;
    }

    /**
     * Getter for the attribute station1
     * @return the attribute station1
     * else null if the station1 is null
     */
    public Station station1(){
        if(station1 == null){ //TODO
            return null;
        }
        return station1;
    }

    /**
     * Getter for the attribute station2
     * @return the attribute station2
     * else null if the station2 is null
     */
    public Station station2(){
        if(station2 == null){ //TODO
            return null;
        }
        return station2;
    }
}
